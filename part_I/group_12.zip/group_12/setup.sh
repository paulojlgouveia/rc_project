
sudo apt-get install python3-pip
sudo pip3 install --upgrade pip

sudo pip3 install networkx
python3 -mpip install matplotlib
sudo apt-get install python3-tk


### for RNL
# rnl-virt disk create myDisk SS
# rnl-virt vm create vm Mad myDisk.qcow2
# rnl-virt vm list
# rnl-virt vm start vm
# rnl-virt vm open vm
# rnl-virt vm stop vm
